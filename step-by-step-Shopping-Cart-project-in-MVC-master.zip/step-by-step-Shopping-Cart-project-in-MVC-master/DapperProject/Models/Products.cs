﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DapperProject.Models
{
    public class productDetails
    {
        public int slno { get; set; }
        public string productName { get; set; }
        public string productDetail { get; set; }
        public int price { get; set; }
    }
}