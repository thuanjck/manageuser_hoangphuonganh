﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_HoangPhuongAnh.Utils
{
    public class Constants
    {
        public static int RULE_ADMIN = 0;
        public static int RULE_USER = 1;
        public static string EMAIL = "email";
    }
}