﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_HoangPhuongAnh.Models.Entities
{
    public class Tbl_loaihang
    {
        public int _maloai { get; set; }

        public string _tenloai { set; get; }
    }
}