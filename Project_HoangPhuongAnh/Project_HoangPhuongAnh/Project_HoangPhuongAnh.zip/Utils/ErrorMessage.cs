﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_HoangPhuongAnh.Utils
{
    public class ErrorMessage
    {
        public static string ER001 = "Sai thông tin tài khoản";
    }
}