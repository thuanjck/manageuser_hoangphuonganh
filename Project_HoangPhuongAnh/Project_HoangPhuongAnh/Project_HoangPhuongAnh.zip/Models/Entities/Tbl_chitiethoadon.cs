﻿namespace Project_HoangPhuongAnh.Models.Entities
{
    public class Tbl_chitiethoadon
    {
        public int _mahd { get; set; }

        public int _masp { get; set; }

        public int _makh { get; set; }

        public string _tensp { get; set; }

        public int _size { get; set; }

        public int _soluong { get; set; }

        public int _dongia { get; set; }

        public int _tinhtrang { get; set; }
    }
}